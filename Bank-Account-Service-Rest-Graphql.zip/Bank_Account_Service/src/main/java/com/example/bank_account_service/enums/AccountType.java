package com.example.bank_account_service.enums;

public enum AccountType {
    CURRENT_ACCOUNT, SAVING_ACCOUNT;
}
