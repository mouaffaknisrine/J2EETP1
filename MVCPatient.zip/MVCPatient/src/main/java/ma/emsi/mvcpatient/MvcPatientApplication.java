package ma.emsi.mvcpatient;

import ma.emsi.mvcpatient.enteties.Patient;
import ma.emsi.mvcpatient.repositories.PatientRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import java.util.Date;

@SpringBootApplication
public class MvcPatientApplication {

    public static void main(String[] args) {

        SpringApplication.run(MvcPatientApplication.class, args);
    }
    //@Bean //pour s'execute automa au demarrage
    CommandLineRunner commandLineRunner(PatientRepository patientRepository){
        return args -> {
            patientRepository.save(
                    new Patient(null,"Hassan",new Date(),false,132));
            patientRepository.save(
                    new Patient(null,"Safaa",new Date(),true,125));
            patientRepository.save(
                    new Patient(null,"Jihane",new Date(),false,142));
            patientRepository.save(
                    new Patient(null,"Oumaima",new Date(),true,262));

            patientRepository.findAll().forEach(p->{
                System.out.println(p.getNom());
            });
        };
    }

}
