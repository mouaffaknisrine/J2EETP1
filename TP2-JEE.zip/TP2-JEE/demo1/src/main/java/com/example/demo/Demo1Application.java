package com.example.demo;

import com.example.demo.entities.Etudiant;
import com.example.demo.repositories.EtudiantRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.util.Date;
import java.util.List;

@SpringBootApplication
public class Demo1Application implements CommandLineRunner {

    @Autowired
    private EtudiantRepo etdRepo;
    public static void main(String[] args) {
        SpringApplication.run(Demo1Application.class, args);
    }


    @Override
    public void run(String... args) throws Exception {
        System.out.println("******************** Insertion **********************");
        etdRepo.save(new Etudiant(null,"A1","Alya",new Date(),true,null));
        etdRepo.save(new Etudiant(null,"A2","Rayan",new Date(),true,null));
        etdRepo.save(new Etudiant(null,"A3","Lilya",new Date(),false,null));
        etdRepo.save(new Etudiant(null,"A4","Amine",new Date(),true,null));
        etdRepo.save(new Etudiant(null,"A5","Ali",new Date(),true,null));
        System.out.println("********************** Inserted rows ************************");
        System.out.println("Count:"+etdRepo.count());
        System.out.println("*************** Display rows ***************");
        List<Etudiant> etudiants = etdRepo.findAll();
        etudiants.forEach(etudiant -> {System.out.println(etudiant.getFullName());});
        System.out.println("*************** Get Elemnt By ID ***************");
        Etudiant etudiant = etdRepo.findById(3).orElse(null);
        System.out.println(etudiant.getFullName());
        System.out.println("*************** Update an Element ***************");
        etudiant.setRegistration_num("S3");
        etdRepo.save(etudiant);
        System.out.println("*************** Display rows ***************");
        List<Etudiant> etu = etdRepo.findAll();
        etu.forEach(etud -> {System.out.println(etud.toString());});
        System.out.println("*************** Delete an Element ***************");
        etdRepo.delete(etudiant);
        System.out.println("Count:"+etdRepo.count());
        etdRepo.deleteById(1);
        System.out.println("Count:"+etdRepo.count());

    }
}
